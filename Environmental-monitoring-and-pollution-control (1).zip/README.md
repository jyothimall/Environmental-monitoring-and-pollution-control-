# AI-Powered Environmental Monitoring & Pollution Control

Run locally:

```bash
pip install -r requirements.txt
python src/model.py  # train model
streamlit run app.py
```
