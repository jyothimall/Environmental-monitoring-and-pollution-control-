import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

def heatmap(df: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(7,5))
    sns.heatmap(df.corr(numeric_only=True), annot=True, cmap='YlGnBu', ax=ax)
    ax.set_title('Correlation Heatmap')
    return fig
