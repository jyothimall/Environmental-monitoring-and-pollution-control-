import pandas as pd

def load_and_clean_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    if df.isnull().sum().any():
        df = df.fillna(df.mean(numeric_only=True))
    return df
