import os, joblib, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

def train_and_save_model(data_path: str, model_path: str) -> str:
    df = pd.read_csv(data_path)
    X = df[['PM2.5','PM10','NO2','SO2','CO']]
    y = df['AQI']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestRegressor(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    joblib.dump(model, model_path)
    return model_path

if __name__ == '__main__':
    p = train_and_save_model('dataset/air_quality.csv','saved_models/aqi_model.pkl')
    print('Model saved to', p)
