import os, joblib, pandas as pd, streamlit as st
from src.preprocessing import load_and_clean_data
from src.visualization import heatmap

st.set_page_config(page_title='Environmental Monitoring Dashboard', layout='wide')
st.title('🌍 AI-Powered Environmental Monitoring & Pollution Control')

DATA_PATH = 'dataset/air_quality.csv'
MODEL_PATH = 'saved_models/aqi_model.pkl'

# Ensure a model file exists
if not os.path.exists(MODEL_PATH):
    from src.model import train_and_save_model
    train_and_save_model(DATA_PATH, MODEL_PATH)

# Load data and model
df = load_and_clean_data(DATA_PATH)
model = joblib.load(MODEL_PATH)

with st.expander('📂 View dataset'):
    st.dataframe(df, use_container_width=True)

st.subheader('🔍 Correlation heatmap')
st.pyplot(heatmap(df))

st.subheader('🔮 Predict AQI')
c1,c2,c3,c4,c5 = st.columns(5)
with c1:
    pm25 = st.number_input('PM2.5', min_value=0.0, value=float(df['PM2.5'].median()))
with c2:
    pm10 = st.number_input('PM10', min_value=0.0, value=float(df['PM10'].median()))
with c3:
    no2 = st.number_input('NO2', min_value=0.0, value=float(df['NO2'].median()))
with c4:
    so2 = st.number_input('SO2', min_value=0.0, value=float(df['SO2'].median()))
with c5:
    co = st.number_input('CO', min_value=0.0, value=float(df['CO'].median()))

if st.button('Predict AQI'):
    X = pd.DataFrame([[pm25, pm10, no2, so2, co]], columns=['PM2.5','PM10','NO2','SO2','CO'])
    pred = model.predict(X)[0]
    st.success(f'🌿 Predicted AQI: {pred:.0f}')
    if pred <= 50:
        st.info('Air Quality: Good')
    elif pred <= 100:
        st.warning('Air Quality: Moderate')
    else:
        st.error('Air Quality: Poor')
